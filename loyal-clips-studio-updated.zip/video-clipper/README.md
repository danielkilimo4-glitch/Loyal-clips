# Loyal Clips Studio

A lightweight, mobile-friendly browser video clipper. Upload a video, choose a section, preview it, and export an MP4 in portrait, square, landscape, or original dimensions.

## Features

- Local video upload (processed in the browser)
- Start/end time controls, sliders, and selection preview
- MP4 export using FFmpeg WebAssembly
- Export aspect ratios:
  - Portrait 9:16 for Shorts, Reels, and TikTok
  - Square 1:1 for feed posts
  - Landscape 16:9 for YouTube
  - Original dimensions
- YouTube URL loading through the optional Python + yt-dlp server
- Responsive layout for mobile screens

## Run locally

For local-file editing, serve the folder with any static web server:

```bash
python3 -m http.server 8080
```

Open `http://localhost:8080`.

For the optional YouTube URL endpoint, install yt-dlp and run:

```bash
pip install -U yt-dlp
python3 server.py
```

Then open `http://localhost:8765`.

## Deploy

GitHub Pages and other static hosts support local file upload and editing. The YouTube URL feature does not work on static hosting alone because it needs the Python backend. Deploy `server.py` to a Python-capable host if you need that endpoint, and configure the frontend API URL if frontend and backend use different domains.

## Notes

- FFmpeg WebAssembly is downloaded from jsDelivr on first export (roughly 30 MB) and cached by the browser.
- Large videos may be slow or exceed available memory on mobile devices. Start with shorter clips.
- Portrait and square exports use a centered crop. Keep important content near the middle.
- This version does not include automatic AI highlight detection or automatic speech-to-text captions yet.
- Only edit and publish videos you have permission to use. Follow the source platform's terms.
