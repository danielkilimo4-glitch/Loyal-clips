# ClipForge — Video Clip Maker

Create short video clips from **local files** or **YouTube URLs**.

- **Local files** → 100% private, runs entirely in the browser.
- **YouTube** → requires the local Python server (or a deployed backend).

## Quick local run (recommended)

```bash
# Install yt-dlp once
pip install -U yt-dlp

cd video-clipper
python3 server.py
```

Open **http://127.0.0.1:8765**

---

## Deploy the website

### Option 1 — Static hosting (easiest, local files only)

YouTube support will **not** work on pure static hosts. File upload + clipping works perfectly.

**Netlify (drag & drop)**
1. Go to [https://app.netlify.com/drop](https://app.netlify.com/drop)
2. Drag the entire `video-clipper` folder
3. Done — you get a live URL instantly

**Vercel**
```bash
npx vercel
```

**GitHub Pages / Cloudflare Pages**
- Push the folder to a repo and enable Pages.
- Point the publish directory to the root (where `index.html` is).

The included `netlify.toml` and `vercel.json` are ready.

### Option 2 — Full deployment (with YouTube support)

You need a platform that can run Python + install `yt-dlp`.

**Recommended: Railway**
1. Create account at [railway.app](https://railway.app)
2. New Project → Deploy from GitHub (or upload)
3. Add a service, set start command:
   ```
   pip install yt-dlp && python server.py
   ```
4. Expose port `8765` (or change `PORT` in `server.py` to use `$PORT`)

**Render**
- Similar: Web Service, Python environment, start command as above.

**Note**: Change the server to listen on `0.0.0.0` and respect the `PORT` environment variable for cloud platforms. Example change in `server.py`:

```python
import os
PORT = int(os.environ.get("PORT", 8765))
HOST = "0.0.0.0"
```

---

## Features

- Upload any common video format
- YouTube URL support (when server is running)
- Precise start/end selection + preview
- High-quality MP4 export via ffmpeg.wasm
- Modern dark UI

## Notes

- First time you create a clip the browser downloads the ffmpeg engine (~30 MB). It is cached afterwards.
- Keep clips reasonably short for best performance in the browser.
- Respect copyright and YouTube Terms of Service.

Enjoy!
