#!/usr/bin/env python3
"""
ClipForge local server
- Serves the static website
- Provides /api/fetch-youtube that downloads a YouTube video with yt-dlp
  and returns it as a video file for the browser to clip.

Usage:
    python3 server.py
    # then open http://localhost:8765
"""

import json
import os
import re
import shutil
import subprocess
import tempfile
import threading
import time
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import urlparse

PORT = int(os.environ.get("PORT", 8765))
HOST = "0.0.0.0"  # listen on all interfaces (needed for cloud deploy)
BASE_DIR = Path(__file__).parent.resolve()
TEMP_DIR = Path(tempfile.gettempdir()) / "clipforge_yt"
TEMP_DIR.mkdir(exist_ok=True)

# Clean old temp files older than 1 hour
def cleanup_old_files():
    now = time.time()
    for f in TEMP_DIR.glob("*"):
        try:
            if now - f.stat().st_mtime > 3600:
                if f.is_file():
                    f.unlink()
                elif f.is_dir():
                    shutil.rmtree(f, ignore_errors=True)
        except Exception:
            pass

cleanup_old_files()


class Handler(SimpleHTTPRequestHandler):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, directory=str(BASE_DIR), **kwargs)

    def log_message(self, format, *args):
        # quieter logs
        print(f"[{self.log_date_time_string()}] {args[0]}")

    def do_OPTIONS(self):
        self.send_response(204)
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "POST, GET, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type")
        self.end_headers()

    def do_POST(self):
        if self.path == "/api/fetch-youtube":
            self.handle_youtube()
        else:
            self.send_error(404, "Not found")

    def handle_youtube(self):
        content_length = int(self.headers.get("Content-Length", 0))
        body = self.rfile.read(content_length)
        try:
            data = json.loads(body.decode("utf-8"))
            url = (data.get("url") or "").strip()
        except Exception:
            self._json_error(400, "Invalid JSON")
            return

        if not url:
            self._json_error(400, "Missing url")
            return

        if not re.search(r"(youtube\.com|youtu\.be)", url, re.I):
            self._json_error(400, "Not a YouTube URL")
            return

        # Create unique temp path
        work_dir = TEMP_DIR / f"job_{int(time.time()*1000)}_{os.getpid()}"
        work_dir.mkdir(parents=True, exist_ok=True)
        out_template = str(work_dir / "video.%(ext)s")

        # Prefer progressive mp4 ≤720p for simplicity and smaller size
        # Fall back to best available under 720p, then any
        format_selector = (
            "best[height<=720][ext=mp4]/"
            "best[height<=720]/"
            "best[ext=mp4]/"
            "best"
        )

        cmd = [
            "yt-dlp",
            "--no-playlist",
            "--no-warnings",
            "-f", format_selector,
            "--merge-output-format", "mp4",
            "-o", out_template,
            "--print", "after_move:filepath",
            url,
        ]

        try:
            print(f"Downloading: {url}")
            result = subprocess.run(
                cmd,
                capture_output=True,
                text=True,
                timeout=180,  # 3 minutes max
                check=False,
            )

            if result.returncode != 0:
                err = (result.stderr or result.stdout or "yt-dlp failed").strip()
                # Clean common noise
                err = re.sub(r"\x1b\[[0-9;]*m", "", err)
                print("yt-dlp error:", err[:500])
                self._json_error(500, f"Download failed: {err[:300]}")
                shutil.rmtree(work_dir, ignore_errors=True)
                return

            # Find the downloaded file
            filepath = None
            for line in reversed(result.stdout.strip().splitlines()):
                line = line.strip()
                if line and Path(line).exists():
                    filepath = Path(line)
                    break

            if not filepath:
                # fallback: look in work_dir
                candidates = list(work_dir.glob("video.*"))
                if candidates:
                    filepath = candidates[0]

            if not filepath or not filepath.exists():
                self._json_error(500, "Download finished but file not found")
                shutil.rmtree(work_dir, ignore_errors=True)
                return

            size = filepath.stat().st_size
            print(f"Downloaded {filepath.name} ({size/1024/1024:.1f} MB)")

            # Stream the file back
            self.send_response(200)
            self.send_header("Content-Type", "video/mp4")
            self.send_header("Content-Length", str(size))
            self.send_header(
                "Content-Disposition",
                f'attachment; filename="{filepath.name}"'
            )
            self.send_header("Access-Control-Allow-Origin", "*")
            self.end_headers()

            with open(filepath, "rb") as f:
                shutil.copyfileobj(f, self.wfile, length=1024 * 256)

            # Cleanup after a short delay so the response can finish
            def delayed_cleanup():
                time.sleep(5)
                shutil.rmtree(work_dir, ignore_errors=True)

            threading.Thread(target=delayed_cleanup, daemon=True).start()

        except subprocess.TimeoutExpired:
            self._json_error(504, "Download timed out (video too long or slow connection)")
            shutil.rmtree(work_dir, ignore_errors=True)
        except Exception as e:
            print("Error:", e)
            self._json_error(500, str(e))
            shutil.rmtree(work_dir, ignore_errors=True)

    def _json_error(self, code, message):
        body = json.dumps({"error": message}).encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Access-Control-Allow-Origin", "*")
        self.end_headers()
        self.wfile.write(body)


def main():
    os.chdir(BASE_DIR)
    server = ThreadingHTTPServer((HOST, PORT), Handler)
    print(f"\n  ClipForge server running on port {PORT}")
    print(f"  Local:   http://127.0.0.1:{PORT}")
    print(f"  Network: http://0.0.0.0:{PORT}")
    print("  Open the Local URL in your browser.\n")
    print("  Press Ctrl+C to stop.\n")
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\nShutting down…")
        server.shutdown()


if __name__ == "__main__":
    main()
